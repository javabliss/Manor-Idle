// Симуляция прогрессии: жадный бот без тапов, шаг 1 сек. Запуск: node tools/sim.js
const E = require('../www/engine.js');
const s = E.newState(0);
const unlocked = {};
let t = 0;
const log = (m) => console.log(String(Math.round(t / 6) / 10).padStart(7) + ' мин  ' + m);

function bestPurchase() {
  const base = E.incomePerSec(s, 0);
  let best = null;
  for (let i = 0; i < E.ROOMS.length; i++) {
    const cost = E.costOf(i, s.levels[i], 1);
    const old = s.levels[i]; s.levels[i]++;
    const gain = E.incomePerSec(s, 0) - base; s.levels[i] = old;
    const payback = cost / Math.max(gain, 1e-9);
    if (!best || payback < best.payback) best = { type: 'room', i, cost, payback };
  }
  for (const u of E.UPGRADES) {
    if (s.ups[u.id]) continue;
    if (u.room !== undefined && s.levels[u.room] < u.minLevel) continue;
    s.ups[u.id] = true;
    const gain = E.incomePerSec(s, 0) - base; delete s.ups[u.id];
    const payback = u.cost / Math.max(gain, 1e-9);
    if (!best || payback < best.payback) best = { type: 'up', u, cost: u.cost, payback };
  }
  return best;
}

const MAX = 24 * 3600;
for (; t < MAX; t++) {
  E.tick(s, 1, 0);
  if (s.levels[0] === 0 && s.coins >= 15) { E.buyLevels(s, 0, 1); }
  for (let k = 0; k < 20; k++) {
    const b = bestPurchase();
    if (!b || b.cost > s.coins) break;
    if (b.type === 'room') E.buyLevels(s, b.i, 1); else E.buyUpgrade(s, b.u.id);
  }
  E.ROOMS.forEach((r, i) => {
    if (s.levels[i] > 0 && !unlocked[i]) { unlocked[i] = 1; log('открыта комната: ' + r.name + ' (доход ' + E.fmt(E.incomePerSec(s, 0)) + '/с)'); }
  });
  [10, 25, 50, 100].forEach((L) => {
    const key = 'h' + L;
    if (s.levels[0] >= L && !unlocked[key]) { unlocked[key] = 1; log('холл достиг уровня ' + L); }
  });
  if (E.prestigeGain(s) >= 1 && !unlocked.p1) { unlocked.p1 = 1; log('первое наследие доступно: +' + E.prestigeGain(s)); }
  if (E.prestigeGain(s) >= 10 && !unlocked.p10) { unlocked.p10 = 1; log('наследие +10 доступно'); }
  if (Math.min(...s.levels) >= 100 && !unlocked.all100) { unlocked.all100 = 1; log('все комнаты на 100'); break; }
}
console.log('\nИтог за ' + Math.round(t / 60) + ' мин: монет заработано ' + E.fmt(s.run) + ', доход ' + E.fmt(E.incomePerSec(s, 0)) + '/с, уровни ' + s.levels.join(','));
