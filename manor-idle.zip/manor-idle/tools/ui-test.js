// Прогон в headless Chromium: проверка ошибок консоли и скриншоты. node tools/ui-test.js <outdir>
const { chromium } = require('playwright');
const out = process.argv[2] || '.';
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' , args:['--no-sandbox']});
  const p = await b.newPage({ viewport: { width: 412, height: 860 } });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await p.goto('file://' + process.cwd() + '/www/index.html');
  await p.waitForTimeout(500);
  await p.click('.dlg .btn');
  for (let i = 0; i < 30; i++) await p.click('#tapBtn');
  await p.click('#buy0');
  await p.screenshot({ path: out + '/1-start.png' });
  // прокачка: даём монет и поднимаем уровни, проверяем все стадии
  await p.evaluate(() => { const s = __game.state; s.coins = 1e12; s.lifetime = 1e12; s.run = 1e12; });
  await p.click('.modes button[data-m="max"]');
  for (let r = 0; r < 7; r++) { const el = await p.$('#buy' + r); if (el) { await el.click(); await p.waitForTimeout(50);} }
  await p.evaluate(() => { const s = __game.state; s.levels = [100,60,30,15,6,2,1]; s.coins = 1e9; });
  await p.evaluate(() => __game.setTab('home'));
  await p.screenshot({ path: out + '/2-mid.png', fullPage: false });
  await p.evaluate(() => { document.getElementById('view').scrollTop = 700; });
  await p.screenshot({ path: out + '/3-rooms.png' });
  await p.evaluate(() => { const s = __game.state; s.levels = [120,110,100,100,100,100,100]; __game.setTab('home'); });
  await p.screenshot({ path: out + '/4-late.png' });
  for (const t of ['ups','quests','heir','shop']) { await p.evaluate(t => __game.setTab(t), t); await p.screenshot({ path: out + '/5-' + t + '.png' }); }
  // реклама (тест) и покупка
  await p.evaluate(() => __game.setTab('shop'));
  await p.click('#adGem'); await p.waitForTimeout(3400);
  p.on('dialog', d => d.accept());
  await p.click('[data-p="golden_key"]'); await p.waitForTimeout(200);
  console.log('gems', await p.evaluate(() => __game.state.gems), 'key', await p.evaluate(() => __game.state.goldenKey));
  // престиж
  await p.evaluate(() => { __game.state.run = 5e9; __game.setTab('heir'); });
  await p.click('#prest'); await p.click('#modal .btn.green'); 
  console.log('heirloom', await p.evaluate(() => __game.state.heirloom), 'levels', await p.evaluate(() => __game.state.levels.join()));
  console.log('ERRORS:', errs.length ? errs : 'none');
  await b.close();
})();
