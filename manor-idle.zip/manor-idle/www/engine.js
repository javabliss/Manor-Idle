/* Движок игры «Возрождение особняка».
 * Чистая логика без DOM — работает и в браузере (window.Engine), и в Node (для тестов). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Engine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var SAVE_KEY = 'manor_idle_save_v1';
  var OFFLINE_CAP_SEC = 8 * 3600;   // максимум офлайн-дохода — 8 часов
  var OFFLINE_RATE = 0.5;           // офлайн приносит 50% дохода
  var PRESTIGE_DIV = 5e7;           // чем меньше, тем щедрее наследие
  var HEIRLOOM_BONUS = 0.10;        // +10% к доходу за каждое наследие

  // Порог уровней: на этих уровнях комната получает множитель x2 и новый вид
  var MILESTONES = [10, 25, 50, 100, 150, 200, 300, 400, 500, 650, 800, 1000];
  // Этапы восстановления для графики: 0 — заколочена, 1..5 — всё лучше
  var STAGE_LEVELS = [1, 10, 25, 50, 100];

  var ROOMS = [
    { id: 'hall',    name: 'Парадный холл',     desc: 'Лицо особняка. С чего-то надо начинать.', baseCost: 15,       rate: 0.5,    coef: 1.15 },
    { id: 'kitchen', name: 'Кухня',             desc: 'Здесь снова запахнет пирогами.',           baseCost: 300,      rate: 3.2,    coef: 1.15 },
    { id: 'library', name: 'Библиотека',        desc: 'Тысячи книг ждут читателей.',              baseCost: 7000,     rate: 19,     coef: 1.15 },
    { id: 'garden',  name: 'Зимний сад',        desc: 'Стеклянный купол и редкие растения.',      baseCost: 2.2e5,    rate: 115,    coef: 1.15 },
    { id: 'ballroom',name: 'Бальный зал',       desc: 'Паркет, хрусталь и музыка.',               baseCost: 3e6,      rate: 800,   coef: 1.15 },
    { id: 'observ',  name: 'Обсерватория',      desc: 'Телескоп смотрит на звёзды.',              baseCost: 8e7,      rate: 6000,  coef: 1.15 },
    { id: 'tower',   name: 'Часовая башня',     desc: 'Когда часы пойдут, особняк оживёт.',       baseCost: 2.5e9,    rate: 45000, coef: 1.15 }
  ];

  // Улучшения (покупаются один раз за монеты). effect: tap / room / all
  var UPGRADES = [
    { id: 'u_broom',  name: 'Хорошая метла',        desc: 'Тап x2',                 cost: 100,    tap: 2 },
    { id: 'u_vac',    name: 'Пылесос',              desc: 'Тап x3',                 cost: 40000,  tap: 3 },
    { id: 'u_crew',   name: 'Бригада реставраторов',desc: 'Тап x5',                 cost: 1e8,    tap: 5 },
    { id: 'u_light',  name: 'Проводка',             desc: 'Доход всех комнат x1.5', cost: 20000,  all: 1.5 },
    { id: 'u_paint',  name: 'Свежая краска',        desc: 'Доход всех комнат x2',   cost: 5e6,    all: 2 },
    { id: 'u_staff',  name: 'Штат прислуги',        desc: 'Доход всех комнат x3',   cost: 1.5e9,  all: 3 }
  ];
  // По одному улучшению на каждую комнату (x3). Стоимость = 250 * базовая цена, нужен уровень 5
  ROOMS.forEach(function (r, i) {
    UPGRADES.push({ id: 'u_room_' + r.id, name: 'Мастера: ' + r.name, desc: 'Доход комнаты x3 (нужен уровень 5)',
      cost: Math.round(r.baseCost * 400), room: i, minLevel: 5, mult: 3 });
  });

  // Задания по главам. progress считается из состояния
  var MISSIONS = [
    { id: 'm1',  ch: 1, text: 'Расчистить холл: уровень 5',            kind: 'level', room: 0, target: 5,   gems: 2 },
    { id: 'm2',  ch: 1, text: 'Сделать 50 тапов метлой',                kind: 'taps',  target: 50,           gems: 2 },
    { id: 'm3',  ch: 1, text: 'Открыть кухню',                          kind: 'level', room: 1, target: 1,   gems: 3 },
    { id: 'm4',  ch: 2, text: 'Холл: уровень 25 — он засияет!',         kind: 'level', room: 0, target: 25,  gems: 4 },
    { id: 'm5',  ch: 2, text: 'Открыть библиотеку',                     kind: 'level', room: 2, target: 1,   gems: 4 },
    { id: 'm6',  ch: 2, text: 'Заработать 100 тыс. монет за всё время', kind: 'life',  target: 1e5,          gems: 5 },
    { id: 'm7',  ch: 3, text: 'Открыть зимний сад',                     kind: 'level', room: 3, target: 1,   gems: 6 },
    { id: 'm8',  ch: 3, text: 'Кухня: уровень 50',                      kind: 'level', room: 1, target: 50,  gems: 6 },
    { id: 'm9',  ch: 3, text: 'Купить 5 улучшений',                     kind: 'ups',   target: 5,            gems: 8 },
    { id: 'm10', ch: 4, text: 'Открыть бальный зал',                    kind: 'level', room: 4, target: 1,   gems: 8 },
    { id: 'm11', ch: 4, text: 'Заработать 100 млн монет',               kind: 'life',  target: 1e8,          gems: 10 },
    { id: 'm12', ch: 4, text: 'Первое наследие: пройти перерождение',   kind: 'heir',  target: 1,            gems: 15 },
    { id: 'm13', ch: 5, text: 'Открыть обсерваторию',                   kind: 'level', room: 5, target: 1,   gems: 12 },
    { id: 'm14', ch: 5, text: 'Открыть часовую башню',                  kind: 'level', room: 6, target: 1,   gems: 15 },
    { id: 'm15', ch: 5, text: 'Все комнаты на 100 уровне',              kind: 'all',   target: 100,          gems: 40 }
  ];
  var CHAPTERS = {
    1: 'Глава 1. Первые шаги',
    2: 'Глава 2. Дом оживает',
    3: 'Глава 3. Новые двери',
    4: 'Глава 4. Блеск прошлого',
    5: 'Глава 5. Тайна башни'
  };

  function newState(now) {
    return {
      v: 1,
      coins: 15,
      run: 0,            // заработано в этом забеге
      lifetime: 0,       // заработано за всё время
      gems: 0,
      heirloom: 0,       // накопленные наследия (бонус сохраняется)
      levels: ROOMS.map(function () { return 0; }),
      ups: {},
      done: {},          // выполненные и забранные задания
      taps: 0,
      boostUntil: 0,     // ускорение x2 (мс)
      lastSeen: now || Date.now(),
      goldenKey: false,  // покупка «Золотой ключ»
      purchases: 0,
      sound: true,
      tutorial: false
    };
  }

  function milestoneCount(level) {
    var n = 0;
    for (var i = 0; i < MILESTONES.length; i++) if (level >= MILESTONES[i]) n++;
    return n;
  }
  function stageOf(level) {
    var s = 0;
    for (var i = 0; i < STAGE_LEVELS.length; i++) if (level >= STAGE_LEVELS[i]) s = i + 1;
    return s;
  }
  function nextMilestone(level) {
    for (var i = 0; i < MILESTONES.length; i++) if (level < MILESTONES[i]) return MILESTONES[i];
    return null;
  }

  // Стоимость покупки n уровней, начиная с текущего
  function costOf(idx, level, n) {
    var r = ROOMS[idx], c = r.coef;
    return r.baseCost * Math.pow(c, level) * (Math.pow(c, n) - 1) / (c - 1);
  }
  function maxAffordable(idx, level, coins) {
    var r = ROOMS[idx], c = r.coef;
    var first = r.baseCost * Math.pow(c, level);
    if (coins < first) return 0;
    var n = Math.floor(Math.log(1 + coins * (c - 1) / first) / Math.log(c));
    // защита от ошибок округления
    while (n > 0 && costOf(idx, level, n) > coins) n--;
    return n;
  }

  function heirloomMult(s) { return 1 + HEIRLOOM_BONUS * s.heirloom; }
  function allUpgradeMult(s) {
    var m = s.goldenKey ? 1.5 : 1; // «Золотой ключ» — постоянный бонус +50%
    UPGRADES.forEach(function (u) { if (u.all && s.ups[u.id]) m *= u.all; });
    return m;
  }
  function tapUpgradeMult(s) {
    var m = 1;
    UPGRADES.forEach(function (u) { if (u.tap && s.ups[u.id]) m *= u.tap; });
    return m;
  }
  function roomUpgradeMult(s, idx) {
    var m = 1;
    UPGRADES.forEach(function (u) { if (u.room === idx && s.ups[u.id]) m *= u.mult; });
    return m;
  }
  function boostMult(s, now) { return (s.boostUntil > (now || Date.now())) ? 2 : 1; }

  // Доход комнаты (без учёта временного ускорения)
  function roomBase(s, idx) {
    var lv = s.levels[idx];
    if (lv <= 0) return 0;
    return lv * ROOMS[idx].rate * Math.pow(2, milestoneCount(lv)) * roomUpgradeMult(s, idx);
  }
  function incomePerSec(s, now) {
    var sum = 0;
    for (var i = 0; i < ROOMS.length; i++) sum += roomBase(s, i);
    return sum * allUpgradeMult(s) * heirloomMult(s) * boostMult(s, now);
  }
  function roomIncome(s, idx, now) {
    return roomBase(s, idx) * allUpgradeMult(s) * heirloomMult(s) * boostMult(s, now);
  }
  function tapValue(s, now) {
    return (1 + incomePerSec(s, now) * 0.04) * tapUpgradeMult(s) * heirloomMult(s);
  }

  function earn(s, amount) {
    s.coins += amount; s.run += amount; s.lifetime += amount;
  }
  function tick(s, dt, now) {
    var inc = incomePerSec(s, now) * dt;
    if (inc > 0) earn(s, inc);
    return inc;
  }
  function tap(s, now) {
    var v = tapValue(s, now);
    earn(s, v); s.taps++;
    return v;
  }

  // mode: 1, 10, 100 или 'max'. Возвращает число купленных уровней
  function buyLevels(s, idx, mode) {
    var lv = s.levels[idx], n;
    if (mode === 'max') n = maxAffordable(idx, lv, s.coins);
    else {
      n = mode;
      if (costOf(idx, lv, n) > s.coins) n = 0;
    }
    if (n <= 0) return 0;
    s.coins -= costOf(idx, lv, n);
    s.levels[idx] = lv + n;
    return n;
  }
  function canBuyUpgrade(s, u) {
    if (s.ups[u.id]) return false;
    if (u.room !== undefined && s.levels[u.room] < u.minLevel) return false;
    return s.coins >= u.cost;
  }
  function buyUpgrade(s, id) {
    var u = UPGRADES.filter(function (x) { return x.id === id; })[0];
    if (!u || !canBuyUpgrade(s, u)) return false;
    s.coins -= u.cost; s.ups[id] = true;
    return true;
  }

  // ---- Задания ----
  function missionProgress(s, m) {
    switch (m.kind) {
      case 'level': return s.levels[m.room];
      case 'taps':  return s.taps;
      case 'life':  return s.lifetime;
      case 'ups':   return Object.keys(s.ups).length;
      case 'heir':  return s.heirloom;
      case 'all':   return Math.min.apply(null, s.levels);
    }
    return 0;
  }
  function missionReady(s, m) { return !s.done[m.id] && missionProgress(s, m) >= m.target; }
  function claimMission(s, id) {
    var m = MISSIONS.filter(function (x) { return x.id === id; })[0];
    if (!m || !missionReady(s, m)) return 0;
    s.done[id] = true; s.gems += m.gems;
    return m.gems;
  }

  // ---- Наследие (престиж) ----
  function prestigeGain(s) {
    return Math.max(0, Math.floor(Math.sqrt(s.run / PRESTIGE_DIV)));
  }
  function doPrestige(s, now) {
    var g = prestigeGain(s);
    if (g < 1) return 0;
    s.heirloom += g;
    s.coins = 15; s.run = 0;
    s.levels = ROOMS.map(function () { return 0; });
    s.ups = {};
    s.boostUntil = 0;
    s.lastSeen = now || Date.now();
    return g;
  }

  // ---- Магазин за кристаллы и ускорения ----
  function activateBoost(s, minutes, now) {
    now = now || Date.now();
    var base = Math.max(s.boostUntil, now);
    s.boostUntil = base + minutes * 60000;
  }
  function buyGemBoost(s, now) {
    if (s.gems < 5) return false;
    s.gems -= 5; activateBoost(s, 15, now); return true;
  }
  function buyGemCash(s, now) {
    if (s.gems < 10) return 0;
    s.gems -= 10;
    var amount = Math.max(50, incomePerSec(s, now) * 3600);
    earn(s, amount);
    return amount;
  }

  // Выдача купленного товара (вызывается после успешной оплаты)
  var PRODUCTS = {
    gems_50:    { title: 'Мешочек кристаллов', gems: 50,  price: '99 ₽' },
    gems_300:   { title: 'Сундук кристаллов',  gems: 300, price: '449 ₽' },
    golden_key: { title: 'Золотой ключ',       key: true, price: '349 ₽' }
  };
  function grantProduct(s, id) {
    var p = PRODUCTS[id];
    if (!p) return false;
    if (p.key) { if (s.goldenKey) return false; s.goldenKey = true; }
    if (p.gems) s.gems += p.gems;
    s.purchases++;
    return true;
  }

  // ---- Офлайн-доход ----
  function offlineEarnings(s, now) {
    now = now || Date.now();
    var sec = Math.max(0, (now - (s.lastSeen || now)) / 1000);
    sec = Math.min(sec, OFFLINE_CAP_SEC);
    var amount = incomePerSec(s, 0) * sec * OFFLINE_RATE; // без ускорения
    return { seconds: sec, amount: amount };
  }

  // ---- Сохранение ----
  function serialize(s) { s.lastSeen = Date.now(); return JSON.stringify(s); }
  function deserialize(str, now) {
    var base = newState(now), d;
    try { d = JSON.parse(str); } catch (e) { return base; }
    if (!d || typeof d !== 'object') return base;
    for (var k in base) if (d[k] !== undefined) base[k] = d[k];
    // подстраховка при добавлении новых комнат
    while (base.levels.length < ROOMS.length) base.levels.push(0);
    ['coins', 'run', 'lifetime', 'gems', 'heirloom'].forEach(function (f) {
      if (typeof base[f] !== 'number' || !isFinite(base[f]) || base[f] < 0) base[f] = 0;
    });
    return base;
  }

  // ---- Форматирование чисел ----
  var SUFFIX = ['', ' тыс', ' млн', ' млрд', ' трлн', ' квадр', ' квинт', ' секст', ' септ'];
  function fmt(n) {
    if (!isFinite(n)) return '∞';
    if (n < 1000) return n < 10 ? (Math.floor(n * 10) / 10).toString().replace('.', ',') : Math.floor(n).toString();
    var e = Math.min(Math.floor(Math.log10(n) / 3), SUFFIX.length - 1);
    var v = n / Math.pow(1000, e);
    var s = v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
    return s.replace('.', ',') + SUFFIX[e];
  }
  function fmtTime(sec) {
    sec = Math.floor(sec);
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
    if (h > 0) return h + ' ч ' + m + ' мин';
    if (m > 0) return m + ' мин';
    return sec + ' сек';
  }

  return {
    SAVE_KEY: SAVE_KEY, ROOMS: ROOMS, UPGRADES: UPGRADES, MISSIONS: MISSIONS, CHAPTERS: CHAPTERS,
    MILESTONES: MILESTONES, STAGE_LEVELS: STAGE_LEVELS, HEIRLOOM_BONUS: HEIRLOOM_BONUS,
    newState: newState, costOf: costOf, maxAffordable: maxAffordable,
    stageOf: stageOf, nextMilestone: nextMilestone, milestoneCount: milestoneCount,
    incomePerSec: incomePerSec, roomIncome: roomIncome, tapValue: tapValue,
    tick: tick, tap: tap, earn: earn,
    buyLevels: buyLevels, canBuyUpgrade: canBuyUpgrade, buyUpgrade: buyUpgrade,
    missionProgress: missionProgress, missionReady: missionReady, claimMission: claimMission,
    prestigeGain: prestigeGain, doPrestige: doPrestige,
    activateBoost: activateBoost, buyGemBoost: buyGemBoost, buyGemCash: buyGemCash,
    PRODUCTS: PRODUCTS, grantProduct: grantProduct,
    offlineEarnings: offlineEarnings, serialize: serialize, deserialize: deserialize,
    fmt: fmt, fmtTime: fmtTime, boostMult: boostMult
  };
});
