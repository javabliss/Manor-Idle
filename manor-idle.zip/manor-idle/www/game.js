/* Интерфейс и игровой цикл */
(function () {
  'use strict';
  var E = window.Engine, A = window.Art, M = window.Monetization;
  var $ = function (id) { return document.getElementById(id); };

  var S = load();
  var tab = 'home', mode = 1;
  var lastFrame = Date.now(), lastSave = 0, lastUI = 0, sceneKey = '';

  // ---------- сохранение ----------
  function load() {
    try {
      var raw = localStorage.getItem(E.SAVE_KEY);
      if (raw) return E.deserialize(raw);
    } catch (e) {}
    return E.newState();
  }
  function save() { try { localStorage.setItem(E.SAVE_KEY, E.serialize(S)); } catch (e) {} }

  // ---------- звук (синтез, без файлов) ----------
  var ctx;
  function beep(freq, dur, type, vol) {
    if (!S.sound) return;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || 'triangle'; o.frequency.value = freq;
      g.gain.value = vol || 0.05;
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + dur);
    } catch (e) {}
  }
  function sBuy() { beep(520, .12); setTimeout(function () { beep(780, .16); }, 70); }
  function sTap() { beep(300 + Math.random() * 80, .06, 'square', .025); }
  function sWin() { [523, 659, 784, 1046].forEach(function (f, i) { setTimeout(function () { beep(f, .2); }, i * 90); }); }

  // ---------- утилиты ----------
  function icon(n) { return A.icon(n); }
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toast.h); toast.h = setTimeout(function () { t.hidden = true; }, 2200);
  }
  function floatText(txt, x, y) {
    var d = document.createElement('div'); d.className = 'float'; d.textContent = txt;
    d.style.left = x + 'px'; d.style.top = y + 'px'; $('fx').appendChild(d);
    setTimeout(function () { d.remove(); }, 900);
  }
  function modal(html, buttons) {
    var m = $('modal');
    m.innerHTML = '<div class="dlg">' + html + '<div class="row"></div></div>';
    var row = m.querySelector('.row');
    buttons.forEach(function (b) {
      var el = document.createElement('button'); el.className = 'btn ' + (b.cls || ''); el.textContent = b.text;
      el.onclick = function () { m.hidden = true; if (b.fn) b.fn(); };
      row.appendChild(el);
    });
    m.hidden = false;
  }
  function stages() { return S.levels.map(E.stageOf); }
  function currentChapter() {
    for (var i = 0; i < E.MISSIONS.length; i++) if (!S.done[E.MISSIONS[i].id]) return E.MISSIONS[i].ch;
    return 5;
  }

  // ---------- верхняя панель ----------
  function updateTop() {
    $('coins').textContent = E.fmt(S.coins);
    $('gems').textContent = S.gems;
    $('ips').textContent = '+' + E.fmt(E.incomePerSec(S)) + '/с';
    var b = $('boost'), left = S.boostUntil - Date.now();
    if (left > 0) { b.hidden = false; b.textContent = '⚡x2 ' + Math.ceil(left / 60000) + ' мин'; } else b.hidden = true;
    var ready = E.MISSIONS.filter(function (m) { return E.missionReady(S, m); }).length;
    var bq = $('badgeQuests'); bq.hidden = !ready; bq.textContent = ready;
  }

  // ---------- вкладка «Дом» ----------
  function sceneSignature() { return stages().join(',') + '|' + mode + '|' + tab; }

  function renderHome() {
    var st = stages(), tot = 0; st.forEach(function (x) { tot += x; });
    var pct = Math.round(tot / (st.length * 5) * 100);
    var h = '<div class="facade-wrap">' + A.facade(st) +
      '<div class="chapter"><span>' + E.CHAPTERS[currentChapter()] + '</span><div class="bar"><i style="width:' + pct + '%"></i></div><span>' + pct + '%</span></div></div>';
    h += '<div class="tap-zone"><button class="tap-btn" id="tapBtn">' + icon('broom') + '<span>Расчищать <small id="tapVal"></small></span></button></div>';
    h += '<div class="tap-hint">Нажимайте, чтобы убираться вручную</div>';
    h += '<div class="modes">' + [1, 10, 100, 'max'].map(function (m) {
      return '<button data-m="' + m + '" class="' + (mode === m ? 'on' : '') + '">' + (m === 'max' ? 'МАКС' : 'x' + m) + '</button>';
    }).join('') + '</div>';
    E.ROOMS.forEach(function (r, i) {
      var lv = S.levels[i];
      if (i > 0 && lv === 0 && S.levels[i - 1] === 0) return; // видна только одна следующая закрытая комната
      h += roomCard(i, r, lv);
    });
    $('view').innerHTML = h;
    bindHome();
    updateHome();
  }
  function roomCard(i, r, lv) {
    return '<div class="room' + (lv === 0 ? ' locked' : '') + '" id="room' + i + '">' +
      '<div class="pic" id="pic' + i + '">' + A.scene(i, E.stageOf(lv), E.ROOMS) +
      '<div class="lvl" id="lvl' + i + '"></div><div class="inc" id="inc' + i + '"></div></div>' +
      '<div class="body"><div class="info"><div class="name">' + r.name + '</div><div class="desc">' + r.desc + '</div><div class="ms" id="ms' + i + '"></div></div>' +
      '<button class="buy" id="buy' + i + '"></button></div></div>';
  }
  function bindHome() {
    var tb = $('tapBtn');
    tb.addEventListener('pointerdown', function (ev) {
      ev.preventDefault();
      var v = E.tap(S); sTap();
      floatText('+' + E.fmt(v), ev.clientX - 20, ev.clientY - 30);
      updateTop();
    });
    document.querySelectorAll('.modes button').forEach(function (b) {
      b.onclick = function () { var m = b.dataset.m; mode = m === 'max' ? 'max' : +m; renderHome(); };
    });
    E.ROOMS.forEach(function (r, i) {
      var b = $('buy' + i); if (!b) return;
      b.onclick = function () {
        var before = E.stageOf(S.levels[i]);
        var n = E.buyLevels(S, i, mode);
        if (!n) { beep(150, .1, 'sawtooth'); return; }
        sBuy();
        var after = E.stageOf(S.levels[i]);
        if (after !== before) { // комната «обновилась»
          sWin(); toast('✨ ' + r.name + ': новый вид!');
          var pic = $('pic' + i);
          pic.innerHTML = A.scene(i, after, E.ROOMS) + '<div class="lvl" id="lvl' + i + '"></div><div class="inc" id="inc' + i + '"></div>';
          pic.classList.add('pop');
          renderHome(); return;
        }
        if (S.levels[i] === n) { renderHome(); return; } // комната только что открыта
        updateTop(); updateHome();
      };
    });
  }
  function updateHome() {
    var tv = $('tapVal'); if (tv) tv.textContent = '+' + E.fmt(E.tapValue(S));
    E.ROOMS.forEach(function (r, i) {
      var b = $('buy' + i); if (!b) return;
      var lv = S.levels[i], n = mode === 'max' ? E.maxAffordable(i, lv, S.coins) : mode;
      var shownN = n || (mode === 'max' ? 1 : mode);
      var cost = E.costOf(i, lv, shownN);
      var can = mode === 'max' ? n > 0 : S.coins >= cost;
      b.className = 'buy' + (can ? '' : ' off');
      b.innerHTML = (lv === 0 ? 'Открыть' : 'Улучшить') + '<small>' + E.fmt(cost) + ' · +' + shownN + ' ур.</small>';
      $('lvl' + i).textContent = lv === 0 ? 'Закрыто' : 'Ур. ' + lv;
      $('inc' + i).textContent = lv === 0 ? '' : '+' + E.fmt(E.roomIncome(S, i)) + '/с';
      var nm = E.nextMilestone(lv);
      $('ms' + i).textContent = nm ? 'До x2 дохода: ур. ' + nm : 'Все бонусы получены';
    });
  }

  // ---------- вкладка «Улучшения» ----------
  function renderUps() {
    var h = '<div class="list"><div class="h">Улучшения</div>';
    var shown = 0;
    E.UPGRADES.forEach(function (u) {
      if (S.ups[u.id]) return;
      if (u.room !== undefined && S.levels[u.room] < 1) return;
      shown++;
      var can = E.canBuyUpgrade(S, u);
      var lockTxt = (u.room !== undefined && S.levels[u.room] < u.minLevel);
      h += '<div class="card"><div class="t"><b>' + u.name + '</b><span>' + u.desc + '</span></div>' +
        '<button class="btn ' + (can ? 'green' : 'off') + '" data-u="' + u.id + '">' + (lockTxt ? 'Ур. ' + u.minLevel : E.fmt(u.cost)) + '</button></div>';
    });
    if (!shown) h += '<div class="note">Все доступные улучшения куплены. Откройте новые комнаты!</div>';
    var owned = Object.keys(S.ups).length;
    h += '<div class="note">Куплено улучшений: ' + owned + '</div></div>';
    $('view').innerHTML = h;
    document.querySelectorAll('[data-u]').forEach(function (b) {
      b.onclick = function () { if (E.buyUpgrade(S, b.dataset.u)) { sBuy(); updateTop(); renderUps(); } else beep(150, .1, 'sawtooth'); };
    });
  }

  // ---------- вкладка «Задания» ----------
  function renderQuests() {
    var h = '<div class="list"><div class="h">Задания реставрации</div>', ch = 0;
    E.MISSIONS.forEach(function (m) {
      if (m.ch !== ch) { ch = m.ch; h += '<div class="ch">' + E.CHAPTERS[ch] + '</div>'; }
      var p = E.missionProgress(S, m), done = S.done[m.id], ready = E.missionReady(S, m);
      h += '<div class="card' + (done ? ' done' : '') + '"><div class="t"><b>' + m.text + '</b><span class="prog">' +
        (done ? 'Выполнено' : E.fmt(Math.min(p, m.target)) + ' / ' + E.fmt(m.target)) + '</span></div>' +
        (done ? '' : '<button class="btn ' + (ready ? 'green' : 'off') + '" data-q="' + m.id + '">' + (ready ? 'Забрать ' : '') + m.gems + ' 💎</button>') + '</div>';
    });
    $('view').innerHTML = h + '</div>';
    document.querySelectorAll('[data-q]').forEach(function (b) {
      b.onclick = function () {
        var g = E.claimMission(S, b.dataset.q);
        if (g) { sWin(); toast('+' + g + ' кристаллов'); updateTop(); save(); renderQuests(); } else beep(150, .1, 'sawtooth');
      };
    });
  }

  // ---------- вкладка «Наследие» ----------
  function renderHeir() {
    var g = E.prestigeGain(S), cur = Math.round(S.heirloom * E.HEIRLOOM_BONUS * 100);
    var h = '<div class="list"><div class="h">Наследие рода</div>' +
      '<div class="card"><div class="t"><b>Семейные реликвии: ' + S.heirloom + '</b><span>Каждая даёт +10% ко всему доходу навсегда. Сейчас бонус: +' + cur + '%</span></div></div>' +
      '<div class="note">Если начать реставрацию заново, особняк вернётся в прежнее состояние, но вы получите реликвии за заработанные в этом забеге монеты. Кристаллы, задания и покупки сохраняются.</div>' +
      '<div class="card"><div class="t"><b>Можно получить: +' + g + '</b><span>Заработано в этом забеге: ' + E.fmt(S.run) + '</span></div>' +
      '<button class="btn ' + (g >= 1 ? 'green' : 'off') + '" id="prest">Начать заново</button></div></div>';
    $('view').innerHTML = h;
    $('prest').onclick = function () {
      if (g < 1) { toast('Заработайте ещё монет — нужна хотя бы 1 реликвия'); return; }
      modal('<h3>Начать заново?</h3><p>Вы получите <b>' + g + '</b> реликвий (+' + (g * 10) + '% дохода). Комнаты и улучшения сбросятся.</p>', [
        { text: 'Отмена' },
        { text: 'Да', cls: 'green', fn: function () { E.doPrestige(S); sWin(); save(); setTab('home'); toast('Новое начало! Бонус дохода выше'); } }
      ]);
    };
  }

  // ---------- вкладка «Магазин» ----------
  function renderShop() {
    var boostLeft = S.boostUntil - Date.now();
    var h = '<div class="list"><div class="h">Магазин</div>';
    h += '<div class="card"><span class="ico">' + icon('bolt') + '</span><div class="t"><b>Ускорение x2 на 30 мин</b><span>Посмотрите короткий ролик' + (boostLeft > 0 ? ' (время добавится)' : '') + '</span></div><button class="btn blue" id="adBoost">' + '▶ Смотреть</button></div>';
    h += '<div class="card"><span class="ico">' + icon('gem') + '</span><div class="t"><b>+3 кристалла</b><span>За просмотр ролика</span></div><button class="btn blue" id="adGem">▶ Смотреть</button></div>';
    h += '<div class="ch">За кристаллы</div>';
    h += '<div class="card"><span class="ico">' + icon('bolt') + '</span><div class="t"><b>Ускорение x2 на 15 мин</b><span>5 кристаллов</span></div><button class="btn ' + (S.gems >= 5 ? 'green' : 'off') + '" id="gBoost">5 💎</button></div>';
    h += '<div class="card"><span class="ico">' + icon('coin') + '</span><div class="t"><b>Час дохода сразу</b><span>10 кристаллов</span></div><button class="btn ' + (S.gems >= 10 ? 'green' : 'off') + '" id="gCash">10 💎</button></div>';
    if (M.canBuy()) {
      h += '<div class="ch">Покупки</div>';
      Object.keys(E.PRODUCTS).forEach(function (id) {
        var p = E.PRODUCTS[id], owned = p.key && S.goldenKey;
        h += '<div class="card' + (owned ? ' done' : '') + '"><span class="ico">' + icon(p.key ? 'key' : 'gem') + '</span><div class="t"><b>' + p.title + '</b><span>' +
          (p.key ? 'Навсегда +50% ко всему доходу' : '+' + p.gems + ' кристаллов') + '</span></div>' +
          (owned ? '<span>Куплено</span>' : '<button class="btn" data-p="' + id + '">' + p.price + '</button>') + '</div>';
      });
    }
    h += '<div class="ch">Настройки</div><div class="card"><div class="t"><b>Звук</b></div><button class="btn" id="snd">' + (S.sound ? 'Вкл' : 'Выкл') + '</button></div>';
    h += '<div class="card"><div class="t"><b>Сбросить прогресс</b><span>Удалит всё без возможности восстановления</span></div><button class="btn off" id="reset">Сброс</button></div>';
    h += '</div>';
    $('view').innerHTML = h;

    $('adBoost').onclick = function () { M.showRewarded(function (ok) { if (ok) { E.activateBoost(S, 30); toast('⚡ Ускорение x2 на 30 минут!'); save(); updateTop(); renderShop(); } else toast('Реклама недоступна, попробуйте позже'); }); };
    $('adGem').onclick = function () { M.showRewarded(function (ok) { if (ok) { S.gems += 3; sWin(); toast('+3 кристалла'); save(); updateTop(); renderShop(); } else toast('Реклама недоступна, попробуйте позже'); }); };
    $('gBoost').onclick = function () { if (E.buyGemBoost(S)) { sBuy(); toast('⚡ Ускорение x2 на 15 минут'); updateTop(); renderShop(); } else toast('Не хватает кристаллов'); };
    $('gCash').onclick = function () { var a = E.buyGemCash(S); if (a) { sBuy(); toast('+' + E.fmt(a) + ' монет'); updateTop(); renderShop(); } else toast('Не хватает кристаллов'); };
    $('snd').onclick = function () { S.sound = !S.sound; renderShop(); };
    $('reset').onclick = function () {
      modal('<h3>Сбросить прогресс?</h3><p>Это действие нельзя отменить.</p>', [
        { text: 'Отмена' }, { text: 'Сбросить', cls: 'off', fn: function () { S = E.newState(); save(); setTab('home'); } }]);
    };
    document.querySelectorAll('[data-p]').forEach(function (b) {
      b.onclick = function () {
        var id = b.dataset.p;
        M.buy(id, E.PRODUCTS[id], function (ok) {
          if (ok && E.grantProduct(S, id)) { sWin(); toast('Спасибо за покупку!'); save(); updateTop(); renderShop(); }
          else toast('Покупка не завершена');
        });
      };
    });
  }

  // ---------- вкладки ----------
  function setTab(t) {
    tab = t;
    document.querySelectorAll('#tabs button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === t); });
    ({ home: renderHome, ups: renderUps, quests: renderQuests, heir: renderHeir, shop: renderShop })[t]();
    $('view').scrollTop = 0;
    updateTop();
  }

  // ---------- офлайн-доход ----------
  function showOffline() {
    var o = E.offlineEarnings(S);
    if (o.seconds < 60 || o.amount < 1) return;
    E.earn(S, o.amount);
    modal('<h3>С возвращением!</h3><p>Пока вас не было (' + E.fmtTime(o.seconds) + '), особняк приносил доход.</p><p style="font-size:22px">' + icon('coin').replace('<svg', '<svg width="22" height="22"') + ' +' + E.fmt(o.amount) + '</p>', [
      { text: 'Забрать', cls: 'green' },
      { text: '▶ x2 за рекламу', cls: 'blue', fn: function () {
        M.showRewarded(function (ok) { if (ok) { E.earn(S, o.amount); toast('Награда удвоена!'); updateTop(); } });
      } }
    ]);
  }

  // ---------- главный цикл ----------
  function frame() {
    var now = Date.now(), dt = Math.min((now - lastFrame) / 1000, 1);
    lastFrame = now;
    E.tick(S, dt, now);
    if (now - lastUI > 200) {
      lastUI = now; updateTop();
      if (tab === 'home') updateHome();
    }
    if (now - lastSave > 10000) { lastSave = now; save(); }
    requestAnimationFrame(frame);
  }

  // Сохранение и пересчёт при сворачивании приложения
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) save();
    else { lastFrame = Date.now(); }
  });
  window.addEventListener('pagehide', save);

  // ---------- старт ----------
  function init() {
    $('icoCoin').innerHTML = icon('coin'); $('icoGem').innerHTML = icon('gem');
    document.querySelectorAll('#tabs button').forEach(function (b) {
      b.querySelector('i').innerHTML = icon(b.querySelector('i').dataset.ic);
      b.onclick = function () { setTab(b.dataset.tab); };
    });
    setTab('home');
    showOffline();
    if (!S.tutorial) {
      S.tutorial = true;
      modal('<h3>Старый особняк</h3><p>Вы унаследовали заброшенный дом. Расчищайте комнаты вручную, улучшайте их — и они начнут приносить доход сами, даже когда вы закрыли игру.</p><p>Откройте все комнаты и верните особняку былое величие.</p>', [{ text: 'За работу!', cls: 'green' }]);
    }
    lastFrame = Date.now();
    requestAnimationFrame(frame);
  }
  window.__game = { get state() { return S; }, setTab: setTab, Engine: E }; // для отладки
  init();
})();
