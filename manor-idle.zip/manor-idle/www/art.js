/* Векторная графика: сцены комнат (7 штук, 6 стадий восстановления) и фасад особняка.
 * Всё рисуется кодом в SVG — не пиксельная графика, масштабируется под любой экран. */
(function () {
  'use strict';

  function rng(seed) {                      // детерминированный «рандом», чтобы сцены не мигали
    var x = seed * 9301 + 49297;
    return function () { x = (x * 9301 + 49297) % 233280; return x / 233280; };
  }
  function P(a) { return a.join(' '); }

  var WALL = {
    hall:     ['#c9a57a', '#8a5f3a'],
    kitchen:  ['#d8cdb3', '#a89878'],
    library:  ['#7a4a2e', '#4a2a18'],
    garden:   ['#bfe3d4', '#7fb8a0'],
    ballroom: ['#e6d6b0', '#b79e6a'],
    observ:   ['#1d2250', '#0a0d2a'],
    tower:    ['#9aa3b5', '#5b6580']
  };
  var FLOOR = {
    hall: '#5a3a24', kitchen: '#8b6a4a', library: '#3a2316', garden: '#6b5a44',
    ballroom: '#caa86a', observ: '#2a2f55', tower: '#3c4256'
  };

  function frame(id, stage, inner, extra) {
    var w = WALL[id], f = FLOOR[id];
    var dust = [0.55, 0.5, 0.34, 0.2, 0.08, 0][stage];
    var glow = stage >= 2 ? (0.12 * (stage - 1)) : 0;
    var s = '<svg class="scene stage' + stage + '" viewBox="0 0 240 110" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">';
    s += '<defs>' +
      '<linearGradient id="w-' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + w[0] + '"/><stop offset="1" stop-color="' + w[1] + '"/></linearGradient>' +
      '<radialGradient id="g-' + id + '" cx="0.5" cy="0.25" r="0.7"><stop offset="0" stop-color="#ffe8a8" stop-opacity="0.95"/><stop offset="1" stop-color="#ffe8a8" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="f-' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + f + '"/><stop offset="1" stop-color="#000" stop-opacity=".45"/></linearGradient>' +
      '</defs>';
    s += '<rect width="240" height="110" fill="url(#w-' + id + ')"/>';
    s += '<rect y="80" width="240" height="30" fill="' + f + '"/><rect y="80" width="240" height="30" fill="url(#f-' + id + ')"/>';
    s += '<rect y="78" width="240" height="3" fill="#000" opacity=".25"/>';
    s += inner;
    if (glow) s += '<rect width="240" height="110" fill="url(#g-' + id + ')" opacity="' + glow + '"/>';
    // следы запустения
    if (stage <= 2) {
      s += '<path d="M30 0 L34 14 L29 26 L36 40" stroke="#000" stroke-opacity=".35" fill="none" stroke-width="1.2"/>';
      s += '<path d="M200 0 L195 18 L202 30" stroke="#000" stroke-opacity=".3" fill="none" stroke-width="1"/>';
    }
    if (stage <= 3) {
      s += '<g stroke="#fff" stroke-opacity="' + (stage <= 1 ? 0.7 : 0.4) + '" fill="none" stroke-width=".7">' +
        '<path d="M0 0 L28 26 M0 0 L10 32 M0 0 L32 8 M6 6 Q14 14 8 22 M14 12 Q24 16 20 24"/>' +
        '<path d="M240 0 L212 24 M240 0 L230 30 M240 0 L206 6 M234 6 Q226 14 232 22"/></g>';
    }
    if (dust) s += '<rect width="240" height="110" fill="#1b130c" opacity="' + dust + '"/>';
    if (extra) s += extra;
    return s + '</svg>';
  }

  // ---------- Холл ----------
  function hall(st) {
    var s = '';
    // окна
    [[16, 22], [196, 22]].forEach(function (p) {
      s += '<rect x="' + p[0] + '" y="' + p[1] + '" width="28" height="40" rx="14" fill="' + (st >= 2 ? '#9fd4f0' : '#4b5a68') + '" stroke="#5a3a24" stroke-width="2.5"/>';
      s += '<path d="M' + (p[0] + 14) + ' ' + p[1] + ' V' + (p[1] + 40) + ' M' + p[0] + ' ' + (p[1] + 20) + ' H' + (p[0] + 28) + '" stroke="#5a3a24" stroke-width="1.5"/>';
      if (st < 2) s += '<path d="M' + (p[0] + 4) + ' ' + (p[1] + 8) + ' L' + (p[0] + 20) + ' ' + (p[1] + 30) + '" stroke="#fff" stroke-width="1.2"/>';
      if (st >= 3) s += '<path d="M' + (p[0] - 6) + ' ' + (p[1] - 4) + ' q4 30 0 60 h8 q-4 -30 0 -60Z M' + (p[0] + 34) + ' ' + (p[1] - 4) + ' q-4 30 0 60 h-8 q4 -30 0 -60Z" fill="#8c2b3a" opacity=".9"/>';
    });
    // дверь
    s += '<path d="M98 80 V44 a22 22 0 0 1 44 0 V80Z" fill="#5a3418" stroke="#2e1a0a" stroke-width="2"/>';
    if (st >= 2) s += '<path d="M106 80 V46 a14 14 0 0 1 28 0 V80Z" fill="#7a4a24"/><path d="M120 28 V80" stroke="#2e1a0a" stroke-width="1"/>';
    if (st >= 3) s += '<circle cx="129" cy="62" r="2.4" fill="#e8c34a"/><circle cx="111" cy="62" r="2.4" fill="#e8c34a"/>';
    if (st < 2) s += '<path d="M98 56 L142 72" stroke="#c4a068" stroke-width="5"/><path d="M98 70 L142 52" stroke="#a88650" stroke-width="5"/>';
    // ковёр
    if (st >= 2) s += '<polygon points="88,110 152,110 140,81 100,81" fill="#9b1c31"/>' + (st >= 4 ? '<polygon points="88,110 152,110 150,106 90,106" fill="#e8c34a"/><polygon points="100,81 140,81 141,84 99,84" fill="#e8c34a"/>' : '');
    // портреты
    var tilt = st < 3 ? -12 : 0;
    s += '<g transform="rotate(' + tilt + ' 66 38)"><rect x="54" y="24" width="24" height="30" fill="#c8a24a"/><rect x="57" y="27" width="18" height="24" fill="' + (st >= 3 ? '#e9d6b4' : '#6f6a60') + '"/>' + (st >= 3 ? '<circle cx="66" cy="36" r="5" fill="#b0805a"/><path d="M58 51 q8 -12 16 0Z" fill="#355a8a"/>' : '') + '</g>';
    s += '<g><rect x="164" y="26" width="22" height="28" fill="#c8a24a"/><rect x="167" y="29" width="16" height="22" fill="' + (st >= 3 ? '#cfe3c0' : '#6f6a60') + '"/>' + (st >= 3 ? '<path d="M167 51 L175 38 L183 51Z" fill="#4f8a4a"/><circle cx="178" cy="36" r="3" fill="#f6e08a"/>' : '') + '</g>';
    // люстра
    if (st >= 3) s += '<g class="sway" style="transform-origin:120px 0"><path d="M120 0 V12" stroke="#b69a3e" stroke-width="1.5"/><ellipse cx="120" cy="14" rx="18" ry="4" fill="#d8b64a"/><g fill="#fff3b0"><circle class="flame" cx="106" cy="9" r="2.2"/><circle class="flame" cx="120" cy="7" r="2.2"/><circle class="flame" cx="134" cy="9" r="2.2"/></g><path d="M106 16 v8 M120 18 v10 M134 16 v8" stroke="#e8f4ff" stroke-width="1.4"/></g>';
    // растение
    if (st >= 4) s += '<path d="M206 82 h18 l-3 -16 h-12Z" fill="#8a4a2a"/><path d="M215 66 q-14 -10 -10 -26 q10 6 10 26 M215 66 q14 -10 10 -26 q-10 6 -10 26 M215 66 q0 -18 0 -30" fill="#3f9a4a" stroke="#2c6f35"/>';
    // обломки
    if (st <= 1) s += '<polygon points="30,98 44,88 52,100" fill="#555"/><polygon points="170,100 184,92 196,102" fill="#666"/><rect x="60" y="96" width="30" height="5" fill="#8a6a3a" transform="rotate(-8 75 98)"/>';
    return s;
  }

  // ---------- Кухня ----------
  function kitchen(st) {
    var s = '';
    if (st >= 4) { // плитка
      s += '<g opacity=".5" stroke="#fff" stroke-width=".6">';
      for (var x = 0; x <= 240; x += 12) s += '<path d="M' + x + ' 24 V70"/>';
      for (var y = 24; y <= 70; y += 12) s += '<path d="M0 ' + y + ' H240"/>';
      s += '</g>';
    }
    s += '<rect x="20" y="8" width="44" height="34" rx="2" fill="' + (st >= 2 ? '#a6dcf2' : '#4d5a66') + '" stroke="#6b4a2a" stroke-width="2.5"/><path d="M42 8 V42 M20 25 H64" stroke="#6b4a2a" stroke-width="1.5"/>';
    // шкафы
    s += '<rect x="10" y="62" width="110" height="20" fill="#7a5230"/><rect x="10" y="58" width="110" height="5" fill="' + (st >= 3 ? '#e9e4d6' : '#9a9486') + '"/>';
    s += '<path d="M47 63 V82 M84 63 V82" stroke="#4c3018"/>';
    // плита
    s += '<rect x="148" y="52" width="48" height="30" fill="' + (st >= 3 ? '#3a3f48' : '#2a2c2f') + '"/><rect x="148" y="50" width="48" height="5" fill="#8a8f98"/>';
    s += '<circle cx="162" cy="48" r="6" fill="#222"/><circle cx="182" cy="48" r="6" fill="#222"/>';
    if (st >= 3) s += '<rect x="152" y="64" width="40" height="14" rx="2" fill="#15171a"/><circle cx="172" cy="71" r="3" fill="#ff9a3a" class="flame"/>';
    // кастрюля и пар
    if (st >= 3) s += '<rect x="154" y="38" width="16" height="11" rx="2" fill="#c7ccd4"/><g class="steam" fill="#fff" opacity=".6"><circle cx="160" cy="34" r="3"/><circle cx="165" cy="28" r="3.5"/><circle cx="160" cy="22" r="3"/></g>';
    // подвесные кастрюли
    if (st >= 2) {
      s += '<path d="M80 18 H210" stroke="#6b6b6b" stroke-width="2"/>';
      [[92, '#b5651d'], [114, '#9aa0a8'], [210 - 20, '#b5651d']].forEach(function (p, i) {
        s += '<path d="M' + p[0] + ' 18 V26" stroke="#555"/><ellipse cx="' + p[0] + '" cy="31" rx="7" ry="6" fill="' + p[1] + '"/>';
      });
    }
    // стол и пирог
    s += '<rect x="84" y="86" width="72" height="6" fill="#8a5a30"/><path d="M92 92 V108 M148 92 V108" stroke="#6a4020" stroke-width="3"/>';
    if (st >= 4) s += '<ellipse cx="120" cy="84" rx="11" ry="4" fill="#fff"/><path d="M110 84 q10 -14 20 0Z" fill="#d89a4a"/><circle cx="120" cy="74" r="1.6" fill="#d12"/>';
    if (st >= 5) s += '<path d="M60 90 q10 -6 20 0 v14 h-20Z" fill="#4f86c6"/>';
    if (st <= 1) s += '<polygon points="170,98 190,92 196,104" fill="#5a5a5a"/><path d="M60 100 q10 -4 20 0" stroke="#777" stroke-width="2" fill="none"/>';
    return s;
  }

  // ---------- Библиотека ----------
  function library(st) {
    var r = rng(7), s = '';
    for (var side = 0; side < 2; side++) {
      var x0 = side ? 150 : 8, w = 82;
      s += '<rect x="' + x0 + '" y="6" width="' + w + '" height="74" fill="#2b170c" stroke="#5a3418" stroke-width="2"/>';
      for (var row = 0; row < 4; row++) {
        var y = 8 + row * 18;
        s += '<rect x="' + x0 + '" y="' + (y + 15) + '" width="' + w + '" height="2.5" fill="#6a4020"/>';
        var x = x0 + 3, fill = st >= 3 ? 0.97 : st === 2 ? 0.65 : 0.3;
        while (x < x0 + w - 5) {
          var bw = 3 + r() * 3.4, bh = 9 + r() * 6;
          if (r() < fill) {
            var hue = Math.floor(r() * 360), tl = (st >= 3 && r() < 0.15) ? -12 : 0;
            s += '<rect x="' + x.toFixed(1) + '" y="' + (y + 15 - bh).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + bh.toFixed(1) + '" fill="hsl(' + hue + ',' + (st >= 3 ? 55 : 22) + '%,' + (st >= 3 ? 38 : 30) + '%)"' + (tl ? ' transform="rotate(' + tl + ' ' + x.toFixed(1) + ' ' + (y + 15) + ')"' : '') + '/>';
          }
          x += bw + 0.6;
        }
      }
    }
    // лестница
    if (st >= 4) s += '<path d="M146 6 L166 84" stroke="#a87a4a" stroke-width="3"/><path d="M156 6 L176 84" stroke="#a87a4a" stroke-width="3"/><g stroke="#a87a4a" stroke-width="2"><path d="M148 20 h10 M151 36 h10 M155 52 h10 M159 68 h10"/></g>';
    // кресло и торшер
    if (st >= 3) {
      s += '<path d="M100 84 q-6 -26 8 -32 h24 q14 6 8 32Z" fill="#7a1f2e"/><rect x="104" y="72" width="32" height="14" rx="4" fill="#9a2a3c"/><rect x="98" y="66" width="8" height="20" rx="4" fill="#8a2434"/><rect x="134" y="66" width="8" height="20" rx="4" fill="#8a2434"/>';
      s += '<path d="M186 84 V54" stroke="#c9a23a" stroke-width="2"/><path d="M178 54 h16 l-3 -12 h-10Z" fill="#fff0b0"/>';
    }
    if (st >= 5) s += '<circle cx="120" cy="30" r="10" fill="#3d7ab5"/><path d="M110 30 h20 M120 20 v20" stroke="#fff" opacity=".5"/><path d="M120 40 v6 M114 48 h12" stroke="#c9a23a" stroke-width="2"/>';
    // старый стол с пылью
    if (st <= 2) s += '<rect x="96" y="76" width="48" height="5" fill="#5a3a20"/><path d="M100 81 v14 M140 81 v14" stroke="#5a3a20" stroke-width="3"/>';
    if (st <= 1) s += '<polygon points="60,100 78,92 90,104" fill="#4a4a4a"/>';
    return s;
  }

  // ---------- Зимний сад ----------
  function garden(st) {
    var r = rng(11), s = '';
    s += '<path d="M0 80 V40 Q120 -40 240 40 V80" fill="#cdeff0" opacity=".55"/>';
    s += '<g stroke="#e8f8ff" stroke-width="1.2" fill="none" opacity=".9"><path d="M0 40 Q120 -40 240 40"/><path d="M60 8 V80 M120 -4 V80 M180 8 V80"/><path d="M0 60 H240 M0 40 H240"/></g>';
    if (st <= 1) s += '<path d="M90 10 L110 30 L100 50" stroke="#fff" stroke-width="1.3" fill="none"/>';
    // растения
    var n = [3, 6, 10, 14, 18][Math.max(0, st - 1)];
    for (var i = 0; i < n; i++) {
      var x = 12 + r() * 216, h = (st >= 3 ? 14 + r() * 36 : 6 + r() * 18), dead = st <= 2 && r() < 0.6;
      var col = dead ? '#8a7a4a' : 'hsl(' + (110 + Math.floor(r() * 40)) + ',55%,' + (30 + Math.floor(r() * 15)) + '%)';
      s += '<path d="M' + x.toFixed(1) + ' 84 q' + ((r() - 0.5) * 12).toFixed(1) + ' -' + (h / 2).toFixed(1) + ' ' + ((r() - 0.5) * 8).toFixed(1) + ' -' + h.toFixed(1) + '" stroke="' + col + '" stroke-width="2.2" fill="none"/>';
      s += '<ellipse cx="' + (x + 2).toFixed(1) + '" cy="' + (84 - h).toFixed(1) + '" rx="' + (dead ? 2.5 : 6) + '" ry="' + (dead ? 3 : 4) + '" fill="' + col + '" transform="rotate(' + Math.floor(r() * 90 - 45) + ' ' + x.toFixed(1) + ' ' + (84 - h).toFixed(1) + ')"/>';
      if (st >= 3 && !dead && r() < 0.5) s += '<circle cx="' + (x + 2).toFixed(1) + '" cy="' + (84 - h - 3).toFixed(1) + '" r="2.6" fill="hsl(' + Math.floor(r() * 360) + ',80%,65%)"/>';
    }
    // горшки
    if (st >= 2) s += '<path d="M20 86 h22 l-3 14 h-16Z M198 86 h22 l-3 14 h-16Z" fill="#b5602d"/>';
    // фонтан
    if (st >= 4) {
      s += '<ellipse cx="120" cy="96" rx="30" ry="8" fill="#b9c4cc"/><ellipse cx="120" cy="94" rx="26" ry="6" fill="#58b4e0"/><path d="M120 94 V70" stroke="#a9b4bc" stroke-width="4"/><ellipse cx="120" cy="70" rx="10" ry="3" fill="#b9c4cc"/>';
      s += '<g class="water" stroke="#bfeaff" stroke-width="1.6" fill="none"><path d="M120 70 q-14 -14 -22 4 M120 70 q14 -14 22 4 M120 70 V56"/></g>';
    }
    if (st >= 5) s += '<g class="twinkle" fill="#fff6a0"><circle cx="50" cy="30" r="1.6"/><circle cx="190" cy="26" r="1.6"/><circle cx="150" cy="40" r="1.4"/></g>';
    if (st <= 1) s += '<polygon points="40,100 58,92 66,104" fill="#666"/>';
    return s;
  }

  // ---------- Бальный зал ----------
  function ballroom(st) {
    var s = '';
    if (st >= 2) { // паркет-шашечка
      for (var i = 0; i < 12; i++) for (var j = 0; j < 2; j++) {
        s += '<rect x="' + (i * 20) + '" y="' + (80 + j * 15) + '" width="20" height="15" fill="' + (((i + j) % 2) ? '#e8d8aa' : '#8a6a38') + '" opacity=".75"/>';
      }
    }
    // колонны
    [14, 60, 180, 226].forEach(function (x) {
      s += '<rect x="' + (x - 6) + '" y="10" width="12" height="70" fill="' + (st >= 3 ? '#f1ead8' : '#b6ad98') + '"/><rect x="' + (x - 9) + '" y="8" width="18" height="5" fill="#d8cca8"/><rect x="' + (x - 9) + '" y="77" width="18" height="5" fill="#d8cca8"/>';
    });
    // арочные окна
    [[88, 24], [138, 24]].forEach(function (p) {
      s += '<path d="M' + p[0] + ' 66 V38 a14 14 0 0 1 28 0 V66Z" fill="' + (st >= 2 ? '#2a3a7a' : '#2c2f3a') + '" stroke="#c9a24a" stroke-width="2"/>';
      if (st >= 3) s += '<circle cx="' + (p[0] + 7) + '" cy="40" r="1.2" fill="#fff"/><circle cx="' + (p[0] + 20) + '" cy="50" r="1.2" fill="#fff"/>';
    });
    // шторы
    if (st >= 2) s += '<path d="M0 0 H34 Q22 30 30 80 H0Z M240 0 H206 Q218 30 210 80 H240Z" fill="' + (st >= 4 ? '#a3182f' : '#6a2a2f') + '"/>';
    // люстра
    if (st >= 3) {
      s += '<g class="sway" style="transform-origin:120px 0"><path d="M120 0 V14" stroke="#c9a24a" stroke-width="1.6"/><path d="M96 24 q24 -16 48 0 q-24 6 -48 0Z" fill="#d8b64a"/><path d="M104 24 v10 M112 26 v14 M120 27 v16 M128 26 v14 M136 24 v10" stroke="#eaf6ff" stroke-width="1.6"/><g fill="#fff6b0"><circle class="flame" cx="100" cy="20" r="2"/><circle class="flame" cx="120" cy="14" r="2"/><circle class="flame" cx="140" cy="20" r="2"/></g></g>';
    }
    // рояль
    if (st >= 4) s += '<path d="M150 84 q0 -22 26 -22 h30 q8 0 8 8 v14Z" fill="#14161c"/><rect x="154" y="84" width="48" height="4" fill="#fff"/><path d="M158 88 v14 M198 88 v14" stroke="#14161c" stroke-width="3"/><path d="M166 62 l22 -12 v12Z" fill="#242832"/>';
    if (st >= 5) s += '<g class="twinkle" fill="#ffd96a"><path d="M40 60 l2 5 l5 0 l-4 3 l1.5 5 l-4.5 -3 l-4.5 3 l1.5 -5 l-4 -3 l5 0Z" transform="translate(52 -24) scale(.8)"/></g>';
    if (st <= 1) s += '<polygon points="120,102 140,94 156,104" fill="#555"/><path d="M80 98 h26" stroke="#7a6a50" stroke-width="3"/>';
    return s;
  }

  // ---------- Обсерватория ----------
  function observ(st) {
    var r = rng(3), s = '';
    // купол с щелью
    s += '<path d="M0 80 V40 Q120 -50 240 40 V80Z" fill="#232a5e"/>';
    s += '<path d="M104 -2 L136 -2 L150 80 L90 80Z" fill="#05061a"/>';
    // звёзды
    var n = st >= 2 ? 26 : 8;
    s += '<g class="twinkle" fill="#fff">';
    for (var i = 0; i < n; i++) s += '<circle cx="' + (92 + r() * 56).toFixed(1) + '" cy="' + (4 + r() * 70).toFixed(1) + '" r="' + (0.5 + r() * 1.1).toFixed(2) + '"/>';
    s += '</g>';
    if (st >= 4) s += '<circle cx="124" cy="30" r="9" fill="#e8b66a"/><ellipse cx="124" cy="30" rx="16" ry="3.6" fill="none" stroke="#f4d6a0" stroke-width="1.6" transform="rotate(-18 124 30)"/>';
    // ребра купола
    s += '<g stroke="#4a5aa0" stroke-width="1.2" fill="none" opacity=".7"><path d="M40 60 Q60 20 104 0 M200 60 Q180 20 136 0"/><path d="M0 40 Q120 -50 240 40"/></g>';
    // телескоп
    var ang = st >= 2 ? -48 : -20;
    s += '<path d="M120 80 L106 98 M120 80 L134 98 M120 80 V100" stroke="#8a7a5a" stroke-width="2.4"/>';
    s += '<g transform="rotate(' + ang + ' 120 78)"><rect x="112" y="46" width="16" height="34" rx="3" fill="' + (st >= 3 ? '#c9a24a' : '#7a6a50') + '"/><rect x="110" y="42" width="20" height="6" rx="2" fill="#3a3a44"/><rect x="116" y="70" width="8" height="18" fill="#6a5a3a"/></g>';
    // стол с картами
    if (st >= 3) s += '<rect x="170" y="70" width="50" height="5" fill="#8a5a30"/><path d="M176 75 v22 M214 75 v22" stroke="#6a4020" stroke-width="3"/><rect x="180" y="62" width="22" height="8" fill="#e9dcb6"/><circle cx="212" cy="66" r="4" fill="#3d7ab5"/>';
    if (st >= 5) s += '<path d="M24 80 V50 h20 V80" fill="#2a2f5a" stroke="#c9a24a"/><circle cx="34" cy="62" r="6" fill="#ffe08a"/>';
    if (st <= 1) s += '<polygon points="30,98 46,90 56,102" fill="#4a4a60"/>';
    return s;
  }

  // ---------- Часовая башня ----------
  function tower(st) {
    var s = '';
    // шестерни
    function gear(cx, cy, rr, dir, cls) {
      var teeth = '';
      for (var i = 0; i < 10; i++) teeth += '<rect x="' + (cx - 2.5) + '" y="' + (cy - rr - 4) + '" width="5" height="7" fill="#b58a3a" transform="rotate(' + (i * 36) + ' ' + cx + ' ' + cy + ')"/>';
      return '<g class="' + cls + '" style="transform-origin:' + cx + 'px ' + cy + 'px">' + teeth + '<circle cx="' + cx + '" cy="' + cy + '" r="' + rr + '" fill="#c9a24a"/><circle cx="' + cx + '" cy="' + cy + '" r="' + (rr * 0.45) + '" fill="#5a4416"/></g>';
    }
    if (st >= 2) s += gear(40, 56, 14, 1, 'spin') + gear(70, 78, 10, -1, 'spinr') + gear(200, 60, 16, -1, 'spinr') + gear(176, 86, 9, 1, 'spin');
    // циферблат
    s += '<circle cx="120" cy="52" r="38" fill="#4a3a1a"/><circle cx="120" cy="52" r="34" fill="' + (st >= 2 ? '#f6efdc' : '#8c8670') + '"/>';
    for (var i = 0; i < 12; i++) {
      var a = i * 30 * Math.PI / 180, x1 = 120 + Math.sin(a) * 28, y1 = 52 - Math.cos(a) * 28, x2 = 120 + Math.sin(a) * 32, y2 = 52 - Math.cos(a) * 32;
      s += '<path d="M' + x1.toFixed(1) + ' ' + y1.toFixed(1) + ' L' + x2.toFixed(1) + ' ' + y2.toFixed(1) + '" stroke="#2c2210" stroke-width="' + (i % 3 ? 1.4 : 2.6) + '"/>';
    }
    if (st >= 3) s += '<g class="spin" style="transform-origin:120px 52px;animation-duration:60s"><path d="M120 52 V30" stroke="#1b1408" stroke-width="2.6" stroke-linecap="round"/></g><g class="spin" style="transform-origin:120px 52px;animation-duration:720s"><path d="M120 52 V38" stroke="#1b1408" stroke-width="3.6" stroke-linecap="round"/></g>';
    else s += '<path d="M120 52 L132 66" stroke="#1b1408" stroke-width="2.4"/>';
    s += '<circle cx="120" cy="52" r="3" fill="#c9a24a"/>';
    if (st <= 2) s += '<path d="M96 36 L112 54 L104 70" stroke="#2a2a2a" stroke-width="1.4" fill="none"/>';
    // маятник
    if (st >= 4) s += '<g class="swing" style="transform-origin:120px 90px"><path d="M120 90 V106" stroke="#c9a24a" stroke-width="1.8"/><circle cx="120" cy="106" r="5" fill="#e8c34a"/></g>';
    // колокол
    if (st >= 5) s += '<path d="M104 22 q0 -14 16 -14 q16 0 16 14 l4 4 h-40Z" fill="#e0b13a"/><circle cx="120" cy="28" r="2.5" fill="#6a4a10"/>';
    if (st <= 1) s += '<polygon points="170,100 190,92 200,104" fill="#4a4a55"/>';
    return s;
  }

  var DRAW = { hall: hall, kitchen: kitchen, library: library, garden: garden, ballroom: ballroom, observ: observ, tower: tower };

  // Запертая комната: тёмная, заколоченная досками
  function locked(id) {
    var s = '<svg class="scene stage0" viewBox="0 0 240 110" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">';
    s += '<rect width="240" height="110" fill="#1d1a20"/><rect y="82" width="240" height="28" fill="#141217"/>';
    s += '<g opacity=".5" stroke="#000" stroke-width="1.5"><path d="M30 0 L36 22 L28 40 M190 0 L184 24"/></g>';
    s += '<g><rect x="-10" y="26" width="270" height="16" fill="#8a6a40" transform="rotate(-8 120 34)"/><rect x="-10" y="62" width="270" height="16" fill="#7a5a34" transform="rotate(7 120 70)"/><rect x="-10" y="44" width="270" height="14" fill="#9a7a4c" transform="rotate(-2 120 52)"/></g>';
    s += '<g fill="#3a3a3a"><circle cx="20" cy="30" r="2"/><circle cx="220" cy="38" r="2"/><circle cx="26" cy="68" r="2"/><circle cx="214" cy="62" r="2"/></g>';
    s += '<g stroke="#fff" stroke-opacity=".28" fill="none" stroke-width=".8"><path d="M0 0 L26 22 M0 0 L8 30 M240 0 L214 22"/></g>';
    return s + '</svg>';
  }

  function scene(idx, stage, rooms) {
    var id = rooms[idx].id;
    if (stage <= 0) return locked(id);
    return frame(id, stage, DRAW[id](stage));
  }

  // ---------- Фасад особняка наверху экрана ----------
  // stages: массив этапов по комнатам. avg — общий прогресс 0..1
  function facade(stages) {
    var total = 0; stages.forEach(function (s) { total += s; });
    var avg = total / (stages.length * 5);
    var skyTop = avg > 0.5 ? '#3b5da8' : '#1d2140', skyBot = avg > 0.5 ? '#f4b27a' : '#5a4a6a';
    var s = '<svg class="facade" viewBox="0 0 360 170" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">';
    s += '<defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + skyTop + '"/><stop offset="1" stop-color="' + skyBot + '"/></linearGradient>' +
      '<linearGradient id="wallF" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + (avg > 0.3 ? '#c9b08a' : '#5d5560') + '"/><stop offset="1" stop-color="' + (avg > 0.3 ? '#8f765a' : '#3f3946') + '"/></linearGradient></defs>';
    s += '<rect width="360" height="170" fill="url(#sky)"/>';
    // звёзды / солнце
    if (avg <= 0.5) { var r = rng(5); s += '<g class="twinkle" fill="#fff">'; for (var i = 0; i < 28; i++) s += '<circle cx="' + (r() * 360).toFixed(0) + '" cy="' + (r() * 80).toFixed(0) + '" r="' + (0.5 + r()).toFixed(1) + '"/>'; s += '</g><circle cx="300" cy="30" r="12" fill="#f3efdc"/><circle cx="305" cy="27" r="11" fill="#1d2140" opacity=".85"/>'; }
    else s += '<circle cx="300" cy="46" r="18" fill="#ffe08a" opacity=".95"/>';
    // холмы
    s += '<path d="M0 140 Q80 112 160 138 T360 126 V170 H0Z" fill="' + (avg > 0.3 ? '#4f8a4a' : '#2a3a34') + '"/>';
    // дом
    var wallDark = avg > 0.3 ? '#a88a64' : '#4a4452';
    s += '<g>';
    s += '<rect x="70" y="78" width="220" height="68" fill="url(#wallF)"/>';
    s += '<rect x="30" y="94" width="48" height="52" fill="' + wallDark + '"/><rect x="282" y="94" width="48" height="52" fill="' + wallDark + '"/>';
    s += '<polygon points="64,78 180,42 296,78" fill="' + (avg > 0.3 ? '#8a3a32' : '#3a2f38') + '"/>';
    s += '<polygon points="24,94 54,74 84,94" fill="' + (avg > 0.3 ? '#7a3430' : '#33292f') + '"/><polygon points="276,94 306,74 336,94" fill="' + (avg > 0.3 ? '#7a3430' : '#33292f') + '"/>';
    // башня
    s += '<rect x="158" y="14" width="44" height="66" fill="' + (avg > 0.3 ? '#b89c74' : '#4d4655') + '"/><polygon points="152,16 180,-6 208,16" fill="' + (avg > 0.3 ? '#7a3430' : '#33292f') + '"/>';
    var tw = stages[6] || 0;
    s += '<circle cx="180" cy="40" r="15" fill="' + (tw >= 2 ? '#f6efdc' : '#777') + '" stroke="#3a2c14" stroke-width="2"/>';
    s += (tw >= 3 ? '<path class="hand1" d="M180 40 V30 M180 40 L187 44" stroke="#1b1408" stroke-width="1.8" stroke-linecap="round"/>' : '<path d="M180 40 l5 5" stroke="#222" stroke-width="1.5"/>');
    // дверь
    s += '<path d="M168 146 V122 a12 12 0 0 1 24 0 V146Z" fill="' + (stages[0] >= 2 ? '#7a4a24' : '#2e2220') + '"/>';
    if (stages[0] >= 3) s += '<circle cx="186" cy="136" r="1.6" fill="#e8c34a"/>';
    // окна: по комнатам
    var wins = [[88, 92, 0], [118, 92, 1], [228, 92, 2], [258, 92, 3], [88, 120, 4], [118, 120, 5], [228, 120, 6]];
    wins.forEach(function (w) {
      var st = stages[w[2]] || 0;
      var fillc = st === 0 ? '#14121a' : st === 1 ? '#3a3a40' : '#ffd77a';
      s += '<rect x="' + w[0] + '" y="' + w[1] + '" width="18" height="20" rx="8" fill="' + fillc + '" stroke="#3a2c20" stroke-width="2"/>';
      if (st >= 2) s += '<rect x="' + w[0] + '" y="' + w[1] + '" width="18" height="20" rx="8" fill="#ffe9a8" opacity="' + (0.15 + 0.15 * st) + '" class="flame"/>';
      if (st === 0) s += '<path d="M' + w[0] + ' ' + (w[1] + 6) + ' h18 M' + w[0] + ' ' + (w[1] + 14) + ' h18" stroke="#8a6a40" stroke-width="3"/>';
    });
    s += '</g>';
    // плющ и паутина — исчезают по мере восстановления
    if (avg < 0.5) s += '<path d="M30 146 Q36 118 48 110 Q40 128 52 146 M296 146 Q304 120 318 112 Q310 130 322 146 M70 146 q4 -26 12 -32" stroke="#2e5a34" stroke-width="3" fill="none" opacity="' + (0.9 - avg).toFixed(2) + '"/>';
    // забор / ограда
    s += '<g stroke="' + (avg > 0.3 ? '#2a2a30' : '#14141a') + '" stroke-width="2">';
    for (var x = 4; x < 360; x += 14) s += '<path d="M' + x + ' 166 V' + (avg > 0.2 ? 148 : 152 + (x % 3) * 3) + '"/>';
    s += '<path d="M0 156 H360"/></g>';
    // туман
    s += '<rect y="120" width="360" height="50" fill="#d6dfe8" opacity="' + (0.28 * (1 - avg)).toFixed(2) + '"/>';
    return s + '</svg>';
  }

  // ---------- Иконки ----------
  var ICONS = {
    coin: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#f0b429" stroke="#a86a0c" stroke-width="2"/><circle cx="12" cy="12" r="6.4" fill="none" stroke="#fff3c4" stroke-width="1.6"/><path d="M12 8v8M9.6 10.4c.8-1 4.8-1 4.8 .8s-4.8 .8-4.8 2.6 4 1.8 4.8 .6" stroke="#a86a0c" stroke-width="1.5" fill="none"/></svg>',
    gem: '<svg viewBox="0 0 24 24"><path d="M6 3h12l4 6-10 13L2 9z" fill="#4cc9f0" stroke="#1b7fa3" stroke-width="1.6" stroke-linejoin="round"/><path d="M2 9h20M9 3l-2 6 5 13 5-13-2-6" fill="none" stroke="#d6f6ff" stroke-width="1.2"/></svg>',
    broom: '<svg viewBox="0 0 24 24"><path d="M19 2l-8 9" stroke="#8a5a2a" stroke-width="2.4" stroke-linecap="round"/><path d="M12 10l3 3-4 8H4c3-2 4-6 4-8z" fill="#e0b13a" stroke="#8a6a1a" stroke-width="1.4" stroke-linejoin="round"/></svg>',
    home: '<svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z" fill="currentColor"/></svg>',
    wrench: '<svg viewBox="0 0 24 24"><path d="M14.7 6.3a4 4 0 0 0-5.4 5l-6 6a1.8 1.8 0 0 0 2.6 2.6l6-6a4 4 0 0 0 5-5.4l-2.6 2.6-2.4-.6-.6-2.4z" fill="currentColor"/></svg>',
    flag: '<svg viewBox="0 0 24 24"><path d="M5 2v20M5 4h13l-3 4 3 4H5" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    star: '<svg viewBox="0 0 24 24"><path d="M12 2l3 6.6 7.2.8-5.4 4.8 1.6 7.1L12 17.6 5.6 21.3l1.6-7.1L1.8 9.4 9 8.6z" fill="currentColor"/></svg>',
    bag: '<svg viewBox="0 0 24 24"><path d="M5 8h14l-1 13H6zM9 8V6a3 3 0 0 1 6 0v2" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    bolt: '<svg viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6z" fill="#ffd24a" stroke="#b8860b" stroke-width="1.2" stroke-linejoin="round"/></svg>',
    key: '<svg viewBox="0 0 24 24"><circle cx="8" cy="12" r="5" fill="#f0b429" stroke="#a86a0c" stroke-width="1.6"/><path d="M13 12h9M19 12v4M16 12v3" stroke="#a86a0c" stroke-width="2.4" stroke-linecap="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M6 4l14 8-14 8z" fill="currentColor"/></svg>'
  };

  window.Art = { scene: scene, facade: facade, icon: function (n) { return ICONS[n] || ''; } };
})();
