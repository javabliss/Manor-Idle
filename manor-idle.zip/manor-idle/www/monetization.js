/* Слой монетизации: реклама за награду + покупки.
 * Игра вызывает ТОЛЬКО Monetization.showRewarded(...) и Monetization.buy(...),
 * поэтому провайдера можно сменить, не трогая остальной код.
 *
 *   MODE = 'mock'    — тестовый режим (имитация рекламы и покупок). Для проверки игры.
 *   MODE = 'admob'   — Google AdMob через плагин @capacitor-community/admob (для зарубежной аудитории).
 *   MODE = 'native'  — свой нативный Capacitor-плагин (RuStore Pay SDK, Яндекс Реклама/VK Реклама и т.д.).
 *
 * ВАЖНО: перед публикацией замените MODE и ID блоков (см. README.md, раздел «Монетизация»).
 */
(function () {
  'use strict';

  var CONFIG = {
    MODE: 'mock',
    ADMOB_REWARDED_ID: 'ca-app-pub-3940256099942544/5224354917', // тестовый ID Google — замените на свой
    NATIVE_PLUGIN: 'ManorBilling'                                // имя вашего нативного плагина
  };

  function cap() { return window.Capacitor && window.Capacitor.Plugins ? window.Capacitor.Plugins : {}; }

  // ---------- Тестовый режим ----------
  function mockRewarded(done) {
    var ov = document.createElement('div');
    ov.className = 'ad-overlay';
    ov.innerHTML = '<div class="ad-box"><div class="ad-tag">ТЕСТОВАЯ РЕКЛАМА</div><div class="ad-count">3</div><div class="ad-sub">Здесь будет рекламный ролик</div></div>';
    document.body.appendChild(ov);
    var n = 3, cnt = ov.querySelector('.ad-count');
    var iv = setInterval(function () {
      n--; cnt.textContent = n;
      if (n <= 0) { clearInterval(iv); ov.remove(); done(true); }
    }, 1000);
  }
  function mockBuy(id, product, done) {
    var ok = window.confirm('ТЕСТОВАЯ ПОКУПКА\n' + product.title + ' — ' + product.price + '\n\nНажмите OK, чтобы имитировать успешную оплату.');
    done(ok);
  }

  // ---------- AdMob ----------
  function admobRewarded(done) {
    var AdMob = cap().AdMob;
    if (!AdMob) return done(false);
    var rewarded = false, subs = [];
    function cleanup() { subs.forEach(function (s) { try { s.remove(); } catch (e) {} }); }
    Promise.resolve(AdMob.addListener('onRewardedVideoAdReward', function () { rewarded = true; })).then(function (s) { subs.push(s); });
    Promise.resolve(AdMob.addListener('onRewardedVideoAdDismissed', function () { cleanup(); done(rewarded); })).then(function (s) { subs.push(s); });
    AdMob.prepareRewardVideoAd({ adId: CONFIG.ADMOB_REWARDED_ID })
      .then(function () { return AdMob.showRewardVideoAd(); })
      .catch(function () { cleanup(); done(false); });
  }

  // ---------- Нативный плагин (RuStore Pay, Яндекс Реклама и т.д.) ----------
  // Ожидаемый контракт плагина (его надо написать на Kotlin — см. README):
  //   showRewarded()        -> Promise<{ rewarded: boolean }>
  //   purchase({productId}) -> Promise<{ success: boolean }>
  function nativeRewarded(done) {
    var p = cap()[CONFIG.NATIVE_PLUGIN];
    if (!p || !p.showRewarded) return done(false);
    p.showRewarded().then(function (r) { done(!!(r && r.rewarded)); }).catch(function () { done(false); });
  }
  function nativeBuy(id, product, done) {
    var p = cap()[CONFIG.NATIVE_PLUGIN];
    if (!p || !p.purchase) return done(false);
    p.purchase({ productId: id }).then(function (r) { done(!!(r && r.success)); }).catch(function () { done(false); });
  }

  window.Monetization = {
    CONFIG: CONFIG,
    // Реклама с наградой. done(true) — игрок досмотрел и заслужил награду
    showRewarded: function (done) {
      if (CONFIG.MODE === 'admob') return admobRewarded(done);
      if (CONFIG.MODE === 'native') return nativeRewarded(done);
      return mockRewarded(done);
    },
    // Покупка за реальные деньги. done(true) — оплата прошла
    buy: function (id, product, done) {
      if (CONFIG.MODE === 'native') return nativeBuy(id, product, done);
      if (CONFIG.MODE === 'admob') return done(false); // AdMob покупок не обрабатывает
      return mockBuy(id, product, done);
    },
    canBuy: function () { return CONFIG.MODE !== 'admob'; }
  };
})();
